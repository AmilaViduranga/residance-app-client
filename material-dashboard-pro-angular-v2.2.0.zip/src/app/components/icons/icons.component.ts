import { Component } from '@angular/core';

@Component({
    selector: 'app-icons-cmp',
    templateUrl: 'icons.component.html'
})

export class IconsComponent {}
