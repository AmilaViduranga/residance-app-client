import { Component } from '@angular/core';

@Component({
    selector: 'app-panels-cmp',
    templateUrl: 'panels.component.html'
})

export class PanelsComponent {}
